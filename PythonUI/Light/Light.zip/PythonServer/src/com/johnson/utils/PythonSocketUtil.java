package com.johnson.utils;

//import com.johnson.servlet.PythonWebSocket;

import java.net.UnknownHostException;

public class PythonSocketUtil {
    public static void startSocket(){
        //启动WebSocketService
//        PythonWebSocket webSocketService = null;
//        try {
//            webSocketService = new PythonWebSocket(9002, new Draft_6455());
//            webSocketService.setConnectionLostTimeout(0);
//            webSocketService.start();
//        } catch (UnknownHostException e) {
//            e.printStackTrace();
//        }
    }
}
