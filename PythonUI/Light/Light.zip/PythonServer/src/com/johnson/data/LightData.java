package com.johnson.data;

public class LightData {
    public static Boolean status = true;

    public static void setStatus(Boolean status) {
        LightData.status = status;
    }

    public static Boolean getStatus() {
        return status;
    }
}
